OK_FORMAT = True

test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> query_3, result_3_df = grading_util.load_results('result_3')\n>>> result_3_df.shape == (11, 2)\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': ">>> query_3, result_3_df = grading_util.load_results('result_3')\n>>> result_3_df.columns == ['title', 'artist']\narray([ True,  True])",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> query_3, result_3_df = grading_util.load_results('result_3')\n"
                                               ">>> result_3_df['title'].iloc[:3]\n"
                                               '0      Paint The Town Red\n'
                                               '1             Lovin On Me\n'
                                               '2    Standing Next To You\n'
                                               'Name: title, dtype: object',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> query_3, result_3_df = grading_util.load_results('result_3')\n"
                                               ">>> result_3_df['artist'].iloc[:3]\n"
                                               '0       Doja Cat\n'
                                               '1    Jack Harlow\n'
                                               '2      Jung Kook\n'
                                               'Name: artist, dtype: object',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> query_3, result_3_df = grading_util.load_results('result_3')\n"
                                               ">>> result_3_df['title']\n"
                                               '0                                             Paint The Town Red\n'
                                               '1                                                    Lovin On Me\n'
                                               '2                                           Standing Next To You\n'
                                               '3                                                       Fast Car\n'
                                               '4                                                         Snooze\n'
                                               '5                                                   Cruel Summer\n'
                                               "6            Is It Over Now? (Taylor's Version) [From The Vault]\n"
                                               "7     Now That We Don't Talk (Taylor's Version) [From The Vault]\n"
                                               "8               Say Don't Go (Taylor's Version) [From The Vault]\n"
                                               "9                      Slut! (Taylor's Version) [From The Vault]\n"
                                               '10                                         I Remember Everything\n'
                                               'Name: title, dtype: object',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': ">>> query_3, result_3_df = grading_util.load_results('result_3')\n"
                                               ">>> result_3_df['artist']\n"
                                               '0                                 Doja Cat\n'
                                               '1                              Jack Harlow\n'
                                               '2                                Jung Kook\n'
                                               '3                               Luke Combs\n'
                                               '4                                      SZA\n'
                                               '5                             Taylor Swift\n'
                                               '6                             Taylor Swift\n'
                                               '7                             Taylor Swift\n'
                                               '8                             Taylor Swift\n'
                                               '9                             Taylor Swift\n'
                                               '10    Zach Bryan Featuring Kacey Musgraves\n'
                                               'Name: artist, dtype: object',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
