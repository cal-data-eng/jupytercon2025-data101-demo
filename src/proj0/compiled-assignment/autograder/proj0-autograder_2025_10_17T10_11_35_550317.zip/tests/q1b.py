OK_FORMAT = True

test = {   'name': 'q1b',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> result_1b.shape\n(25, 7)', 'hidden': False, 'locked': False},
                                   {   'code': '>>> str(list(result_1b.columns))\n"[\'week_ending\', \'rank\', \'title\', \'artist\', \'image_url\', \'peak_position\', \'weeks_on_chart\']"',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
