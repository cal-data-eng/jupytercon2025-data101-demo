OK_FORMAT = True

test = {   'name': 'q1a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> result_1a.shape\n(1, 1)', 'hidden': False, 'locked': False},
                                   {'code': '>>> str(list(result_1a.columns))\n"[\'count\']"', 'hidden': False, 'locked': False},
                                   {'code': '>>> result_1a.iloc[0]\ncount    344458\nName: 0, dtype: int64', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
